import * as THREE from 'three';
import {mergeGeometries,mergeVertices} from 'three/addons/utils/BufferGeometryUtils.js';
/** Static material batching preserves geometry and named source-part metadata. */
export function optimizeGroup(group,protectedChild=null){
 group.updateWorldMatrix(true,true);const inverse=group.matrixWorld.clone().invert(),buckets=new Map(),owned=group.children.filter(c=>c!==protectedChild);
 for(const child of owned)child.traverse(o=>{if(!o.isMesh||Array.isArray(o.material))return;const g=o.geometry.clone().applyMatrix4(inverse.clone().multiply(o.matrixWorld));if(!Object.values(o.material).some(value=>value?.isTexture))g.deleteAttribute('uv');const normal=g.getAttribute('normal');for(let i=0;i<normal.count;i++){const n=new THREE.Vector3().fromBufferAttribute(normal,i);if(n.lengthSq()<1e-10)n.set(0,1,0);else n.normalize();normal.setXYZ(i,n.x,n.y,n.z);}const key=[o.material.uuid,o.castShadow,o.receiveShadow,Object.keys(g.attributes).sort().join(',')].join('|');if(!buckets.has(key))buckets.set(key,{material:o.material,cast:o.castShadow,receive:o.receiveShadow,geometries:[],names:[]});const entry=buckets.get(key);entry.geometries.push(g.index?g.toNonIndexed():g);entry.names.push(o.name);if(g.index)g.dispose();});
 for(const child of owned){child.traverse(o=>{if(o.isMesh)o.geometry.dispose();});group.remove(child);}
 for(const b of buckets.values()){const merged=mergeGeometries(b.geometries,false);if(!merged)throw new Error('Failed to merge '+b.material.name);const welded=mergeVertices(merged,1e-6);const positions=welded.getAttribute('position'),indices=welded.index.array,clean=[],va=new THREE.Vector3(),vb=new THREE.Vector3(),vc=new THREE.Vector3();for(let i=0;i<indices.length;i+=3){const a=indices[i],b=indices[i+1],c=indices[i+2];if(a===b||b===c||c===a)continue;va.fromBufferAttribute(positions,a);vb.fromBufferAttribute(positions,b).sub(va);vc.fromBufferAttribute(positions,c).sub(va);if(vb.cross(vc).lengthSq()<=1e-24)continue;clean.push(a,b,c);}welded.setIndex(clean);if(b.material.normalMap&&welded.hasAttribute('uv')){welded.computeTangents();repairTangentBasis(welded);}merged.dispose();b.geometries.forEach(g=>g.dispose());const mesh=new THREE.Mesh(welded,b.material);mesh.name=(b.material.name||'Material')+' / batched geometry';mesh.castShadow=b.cast;mesh.receiveShadow=b.receive;mesh.userData.sourceParts=b.names;mesh.userData.shadow={cast:b.cast,receive:b.receive};group.add(mesh);}
}

function repairTangentBasis(geometry){
 const tangent=geometry.getAttribute('tangent'),normal=geometry.getAttribute('normal');if(!tangent||!normal)return;
 const n=new THREE.Vector3(),t=new THREE.Vector3(),axis=new THREE.Vector3();
 for(let i=0;i<tangent.count;i++){
  n.fromBufferAttribute(normal,i).normalize();t.set(tangent.getX(i),tangent.getY(i),tangent.getZ(i));t.addScaledVector(n,-t.dot(n));
  if(!Number.isFinite(t.lengthSq())||t.lengthSq()<1e-16){axis.set(Math.abs(n.x)<.8?1:0,Math.abs(n.x)<.8?0:1,0);t.crossVectors(axis,n);}
  t.normalize();const sign=tangent.getW(i)<0?-1:1;tangent.setXYZW(i,t.x,t.y,t.z,sign);
 }
 tangent.needsUpdate=true;
}
